public class Category {
    
    private String name;
    private int count;
    
    public Category(String name)
            
    {
    this.name = name;
    this.count = 1;
    }
    
    public Category()
            
    {
    
    }
    
   String get_name()
           
   {
    return name;   
   }
   
   int get_count()
           
   {
    return count;   
   }
   
   
   }
    
    

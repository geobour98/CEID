import java.util.*;
import java.util.Date;
import java.util.Collections;
/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */


public class Main {
    
    
    public static ArrayList<User> userlist = new ArrayList<User>();
    public static ArrayList<Administrator> adminlist = new ArrayList<Administrator>();
    public static ArrayList<Book> booklist = new ArrayList<Book>();
    public static ArrayList<Booking> bookinglist = new ArrayList<Booking>();
    public static ArrayList<Reservation> reservationlist = new ArrayList<Reservation>();
    public static ArrayList<Review> reviewlist = new ArrayList<Review>();
    public static ArrayList<Category> categorylist= new ArrayList<Category>();
    static  Category cat0= new Category("NoCATEGORY");
    public static ArrayList<Message> messagelist = new ArrayList<Message>();
    
    
    public static void main(String args[])
            
            
    {
        
   User user1 = new User("nikos","1234","nik@gmail.com", "path1");
   User user2 = new User("anastasia","0123","anast@gmail.com","path2");
   
   userlist.add(user1);
   userlist.add(user2);
     
  
   Administrator admin1 = new Administrator("giorgos", "12345", "giorgos@gmail.com");
   Administrator admin2 = new Administrator("antwnis","5678","ant@gmail.com");
   
   adminlist.add(admin1);
   adminlist.add(admin2);
   
   Message m1 = new Message("31-05-2020","15.45","giorgos","nikos","Ypenthymish epistrofhs biblioy","Exei lhksei h prothesmia gia thn epistrofh toy biblioy");
   Message m2 = new Message("05-06-2020","18.31","antwnis","anastasia","Ypenthymish lhkshs katoxhs biblioy","Apomenoun 10 meres gia thn epistrofh tou bibliou");
   
   messagelist.add(m1);
   messagelist.add(m2);
   
   HomePage page1 = new HomePage();
   
   Category cat1 = new Category("novel");
   Category cat2 = new Category("literature");
   Category cat3 = new Category("science fiction"); 
   
   categorylist.add(cat1);
   categorylist.add(cat2);
   categorylist.add(cat3);
   categorylist.add(cat0);
   
   
   Book book1 = new Book("1","The Man","Panagiotou",cat1,"The life of Panagiotou",null,8);
   Book book2 = new Book("2","The Kite Runner","Khaled Hosseini",cat1,"The changes in political landscape of Afghanistan is 1970s",null,9);
   Book book3 = new Book("3","The Great Gatsby","Francis Scott Fitzgerald",cat2,"The story is of the fabulously wealthy Jay Gatsby and his new love for the beautiful Daisy Buchanan",null,6);
   Book book4 = new Book("4","Jurassic Park","Michael Chrichton",cat3,"Before it mutated into the mega media franchise “Jurassic World”, it was a smart, thoughtful and gripping sci-fi classic",null,7);
   booklist.add(book1);
   booklist.add(book2); 
   booklist.add(book3);
   booklist.add(book4); 
   
   
   Reservation rez1 = new Reservation( 14,"4","anastasia" , true ,"09-06-2020","12:15" , book4);
   Reservation rez2 = new Reservation( 13,"2","anastasia" , true ,"10-06-2020","10:15", book2);
   reservationlist.add(rez1);
   reservationlist.add(rez2);
   
   Booking kra1 = new Booking(23, "anastasia", "1", "05-01-2020" , "16" , 150);
   Booking kra2 = new Booking(32, "antwnis", "3", "04-25-2020" , "10" , 120);
   bookinglist.add(kra1);
   bookinglist.add(kra2);
   
   page1.setVisible(true);
   
}
  
  
   public static User get_user(String username)
           
   {
       User temp=null;
       
       for(User u: Main.userlist)
           
       {
           
           if(u.get_username().equals(username))
           {
               temp = u;
           }
       }
       
       return temp;
   }
   
   
   public static Administrator get_admin(String username)
           
   {
       Administrator temp=null;
       
       for(Administrator a: Main.adminlist)
           
       {
           
           if(a.get_admname().equals(username))
           {
               temp = a;
           }
       }
       
       return temp;
   }
   
   
}

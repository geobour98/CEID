
import java.util.Collections;


public class Book {
   
   public  String isbn;
   public  String title;
   public  String author;
  public   Integer status = 0  ;
  public   String description;
   
    //status = 0 -> elefthero. status = 1 ->reserved  status = 2 ->booked
    Category category_book;
    Review book_review;
    
    int average_rating;
    
    public Book(String isbn, String title, String author, Category category_book,String description, Review book_review, Integer  average_rating )
            
    {
        
     this.isbn = isbn;
     this.title = title;
     this.author = author;
     
     this.category_book = category_book;
     
     this.description = description;
     
     this.book_review = book_review;
        
     this.average_rating = average_rating;
    } 
public Book(){}
    
    
  public   String get_isbn()
            
    {
    
    
    return isbn;
    }
    
    
   public String get_title()
           
   {
    
    return title;
}
   
public String get_author()
        
{
 return author;   
}
    

public Category get_category()
        
{
    return category_book;
    

}

public String get_description()
        
{
    return description;
}

public Integer get_average_rating()
        
{
    
 return average_rating;   
}

public String get_review_text()
{
    return book_review.get_content();
    
}


}








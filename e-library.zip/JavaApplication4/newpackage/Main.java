import java.util.*;
import java.util.Date;
import java.util.Collections;
/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */


public class Main {
    
    
    public static ArrayList<User> userlist = new ArrayList<User>();
    public static ArrayList<Administrator> adminlist = new ArrayList<Administrator>();
    public static ArrayList<DisplayMessageListForm> usermessagelist= new ArrayList<DisplayMessageListForm>();
    public static ArrayList<Book> booklist = new ArrayList<Book>();
    public static ArrayList<MΕSSAGE_LIST_AD> ADmessagelist= new ArrayList<MΕSSAGE_LIST_AD>();   
    public static ArrayList<Booking> bookinglist = new ArrayList<Booking>();
    public static ArrayList<Reservation> reservationlist = new ArrayList<Reservation>();
    public static ArrayList<Review> reviewlist = new ArrayList<Review>();
    public static ArrayList<Category> categorylist= new ArrayList<Category>();
    
    
    public static void main(String args[])
            
            
    {
        
   
   User user1 = new User("nikos","1234","nik@gmail.com", "path1");
   
   userlist.add(user1);
     
   Administrator admin1 = new Administrator("giorgos", "12345", "giorgos@gmail.com");
   
   adminlist.add(admin1);
   
   HomePage page1 = new HomePage();
   Category cat1 = new Category("thriler",2);
   Book book1 = new Book("a","b","c",cat1,"dis",null,124);
   booklist.add(book1); 
   page1.setVisible(true);
   
   
   
        
    }
  
  
   public static User get_user(String username)
           
   {
       User temp=null;
       
       for(User u: Main.userlist)
           
       {
           
           if(u.get_username().equals(username))
           {
               temp = u;
           }
       }
       
       return temp;
   }
   
   
   public static Administrator get_admin(String username)
           
   {
       Administrator temp=null;
       
       for(Administrator a: Main.adminlist)
           
       {
           
           if(a.get_admname().equals(username))
           {
               temp = a;
           }
       }
       
       return temp;
   }
   
   
}

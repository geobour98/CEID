/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author 7_USER
 */
public class Category {
    
    private String name;
    private int count;
    
    public Category(String name, int count)
            
    {
    this.name = name;
    this.count = count;
    }
    
   String get_name()
           
   {
    return name;   
   }
   
   int get_count()
           
   {
    return count;   
   }
   }
    
    
